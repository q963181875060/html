-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/14 on 04:32
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_contentreports
-- Snapshot Table  : 1473827541_contentreports
--
-- SQL    : SELECT * FROM wp_contentreports LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473827541_contentreports`
--
DROP TABLE  IF EXISTS `1473827541_contentreports`;
CREATE TABLE `1473827541_contentreports` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reason` tinytext NOT NULL,
  `status` varchar(55) NOT NULL,
  `details` text,
  `reporter_name` varchar(55) DEFAULT '',
  `reporter_email` varchar(55) DEFAULT '',
  `post_id` mediumint(9) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



--
-- Data for table `wp_contentreports`
-- Number of rows: 1
--
INSERT INTO `1473827541_contentreports` VALUES 
(1,'2016-09-13 13:27:33','内容不符','new','1','','',92);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
