-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/14 on 04:32
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_users
-- Snapshot Table  : 1473827541_users
--
-- SQL    : SELECT * FROM wp_users LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473827541_users`
--
DROP TABLE  IF EXISTS `1473827541_users`;
CREATE TABLE `1473827541_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_users`
-- Number of rows: 3
--
INSERT INTO `1473827541_users` VALUES 
(1,'owen','$P$BAnkvUPMtm9YriUVFx8mAPc91ND6w10','owen','279340843@qq.com','','2016-09-07 06:14:20','1473644602:$P$BBkyrDy3Fs04IzYC0g87C.J6XJWkYr1',0,'owen'),
 (2,'291477321','$P$Bke4aEtBwst6XJHLsabP1VhaJFsttd0','291477321','291477321@qq.com','http://www.360doc.com/content/11/0715/11/474846_133688425.shtml','2016-09-07 06:28:46','1473645490:$P$BXhsmBqVP.d5rk9IRLQKW7csLOydaz/',0,'nicheng'),
 (3,'liujiahe','$P$BA7uWdkRBzkQ6AzmvGqJ.SkIg3UjG51','liujiahe','liujiahe14@mails.tsinghua.edu.cn','','2016-09-10 01:45:41','',0,'liujiahe');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
