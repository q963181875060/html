-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/14 on 04:32
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_term_taxonomy
-- Snapshot Table  : 1473827541_term_taxonomy
--
-- SQL    : SELECT * FROM wp_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 20
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473827541_term_taxonomy`
--
DROP TABLE  IF EXISTS `1473827541_term_taxonomy`;
CREATE TABLE `1473827541_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_term_taxonomy`
-- Number of rows: 20
--
INSERT INTO `1473827541_term_taxonomy` VALUES 
(1,1,'category','',0,11),
 (2,2,'post_format','',0,1),
 (3,3,'bp-email-type','A member has replied to an activity update that the recipient posted.',0,1),
 (4,4,'bp-email-type','A member has replied to a comment on an activity update that the recipient posted.',0,1),
 (5,5,'bp-email-type','Recipient was mentioned in an activity update.',0,1),
 (6,6,'bp-email-type','Recipient was mentioned in a group activity update.',0,1),
 (7,7,'bp-email-type','Recipient has registered for an account.',0,1),
 (8,8,'bp-email-type','Recipient has registered for an account and site.',0,1),
 (9,9,'bp-email-type','A member has sent a friend request to the recipient.',0,1),
 (10,10,'bp-email-type','Recipient has had a friend request accepted by a member.',0,1),
 (11,11,'bp-email-type','A group\'s details were updated.',0,1),
 (12,12,'bp-email-type','A member has sent a group invitation to the recipient.',0,1),
 (13,13,'bp-email-type','Recipient\'s status within a group has changed.',0,1),
 (14,14,'bp-email-type','A member has requested permission to join a group.',0,1),
 (15,15,'bp-email-type','Recipient has received a private message.',0,1),
 (16,16,'bp-email-type','Recipient has changed their email address.',0,1),
 (17,17,'bp-email-type','Recipient had requested to join a group, which was accepted.',0,1),
 (18,18,'bp-email-type','Recipient had requested to join a group, which was rejected.',0,1),
 (19,19,'post_format','',0,1),
 (20,20,'nav_menu','',0,4);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
