-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/14 on 04:32
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_usermeta
-- Snapshot Table  : 1473827541_usermeta
--
-- SQL    : SELECT * FROM wp_usermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 96
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473827541_usermeta`
--
DROP TABLE  IF EXISTS `1473827541_usermeta`;
CREATE TABLE `1473827541_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_usermeta`
-- Number of rows: 96
--
INSERT INTO `1473827541_usermeta` VALUES 
(1,1,'nickname','owen'),
 (78,1,'sex',''),
 (3,1,'last_name',''),
 (4,1,'description',''),
 (5,1,'rich_editing','true'),
 (6,1,'comment_shortcuts','false'),
 (7,1,'admin_color','fresh'),
 (8,1,'use_ssl','0'),
 (9,1,'show_admin_bar_front','true'),
 (10,1,'wp_capabilities','a:1:{s:13:"administrator";b:1;}'),
 (11,1,'wp_user_level','10'),
 (12,1,'dismissed_wp_pointers',''),
 (13,1,'show_welcome_panel','1'),
 (31,1,'session_tokens','a:6:{s:64:"c3d8d420d5f9ac2a0cc899ca2cdf612922795dbefb01f1934762f4122c126509";a:4:{s:10:"expiration";i:1474688807;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473479207;}s:64:"3a4ecc17b1b9194814fdfef7d3e100adf83f69549637bff8a38392a013d45c84";a:4:{s:10:"expiration";i:1474769677;s:2:"ip";s:15:"166.111.163.204";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473560077;}s:64:"39776025f527804a2078801670085be1b77126364da2767111793f76d8d4f579";a:4:{s:10:"expiration";i:1474853130;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473643530;}s:64:"114de1da46179b0e0376ce313ea32699a57eef0017199638a3a3dad7a94a1b94";a:4:{s:10:"expiration";i:1473910382;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473737582;}s:64:"b51c12896c5e2d04f97ef4818ede101628dbf63a261bd9a4d57e023561da65ff";a:4:{s:10:"expiration";i:1473977972;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473805172;}s:64:"15251556746622d2bf7a51329465335f89a55d102054884ea2c3eb9b60ea60d7";a:4:{s:10:"expiration";i:1475026042;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473816442;}}'),
 (66,2,'meta-box-order_dashboard','a:4:{s:6:"normal";s:16:"dashboard_widget";s:4:"side";s:12:"rwp_meta_id1";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
 (67,2,'closedpostboxes_dashboard','a:0:{}'),
 (68,2,'metaboxhidden_dashboard','a:0:{}'),
 (15,1,'wp_dashboard_quick_press_last_post_id','3'),
 (16,1,'wp_user-settings','libraryContent=browse&editor=tinymce&mfold=o'),
 (17,1,'wp_user-settings-time','1473733024'),
 (19,2,'nickname','nicheng'),
 (20,2,'first_name','291477321'),
 (21,2,'last_name',''),
 (22,2,'description','一个好孩纸！就是我！！'),
 (23,2,'rich_editing','true'),
 (24,2,'comment_shortcuts','false'),
 (25,2,'admin_color','fresh'),
 (26,2,'use_ssl','0'),
 (27,2,'show_admin_bar_front','true'),
 (28,2,'wp_capabilities','a:1:{s:6:"author";b:1;}'),
 (29,2,'wp_user_level','2'),
 (30,2,'default_password_nag',''),
 (32,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
 (33,1,'metaboxhidden_nav-menus','a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
 (34,3,'nickname','liujiahe'),
 (35,3,'first_name',''),
 (36,3,'last_name',''),
 (37,3,'description',''),
 (38,3,'rich_editing','true'),
 (39,3,'comment_shortcuts','false'),
 (40,3,'admin_color','fresh'),
 (41,3,'use_ssl','0'),
 (42,3,'show_admin_bar_front','true'),
 (43,3,'wp_capabilities','a:1:{s:6:"author";b:1;}'),
 (44,3,'wp_user_level','2'),
 (45,3,'default_password_nag',''),
 (53,3,'session_tokens','a:2:{s:64:"62219fce6c97af0c476f43c2bbb19cee49a359467a135f818a78ef2f03d40b30";a:4:{s:10:"expiration";i:1474708335;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473498735;}s:64:"0a9e3c8fea624e8020332d124527da14ba0bd42dc1d3b319c0843d436f9b0a0a";a:4:{s:10:"expiration";i:1473834247;s:2:"ip";s:13:"101.5.104.125";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473661447;}}'),
 (47,2,'wp_user-settings','mfold=o&editor=tinymce&post_dfw=off&libraryContent=upload'),
 (48,2,'wp_user-settings-time','1473817746'),
 (50,2,'wp_dashboard_quick_press_last_post_id','11'),
 (51,2,'bp_xprofile_visibility_levels','a:1:{i:1;s:6:"public";}'),
 (52,2,'last_activity','2016-09-10 09:10:10'),
 (54,3,'last_activity','2016-09-10 09:42:28'),
 (58,3,'wp_user-settings','mfold=o'),
 (55,3,'wp_dashboard_quick_press_last_post_id','39'),
 (56,1,'last_activity','2016-09-10 09:44:21'),
 (61,1,'sb_we_last_sent','1473644601'),
 (59,3,'wp_user-settings-time','1473560541'),
 (60,1,'profile_image_id','6'),
 (63,2,'wp_media_library_mode','list'),
 (64,1,'hu_last_tgmpa_notice','a:2:{s:7:"version";s:5:"3.2.2";s:13:"dismiss_count";i:0;}'),
 (69,2,'session_tokens','a:5:{s:64:"615ffa7fa5ab30563eb5a6065b7c175cf232d1c1e3474c1c067926158f93e021";a:4:{s:10:"expiration";i:1473903728;s:2:"ip";s:15:"166.111.163.204";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473730928;}s:64:"c82b2aabdd79933ecf864ff2289e4fa16b772427425d69ed19b62e7bdbe20814";a:4:{s:10:"expiration";i:1473910359;s:2:"ip";s:15:"159.203.228.184";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473737559;}s:64:"ecfbe08e3bb9fb042f30bd919b15cbcafa32a87af8e48d2c0b66fb20cf325d6b";a:4:{s:10:"expiration";i:1474966104;s:2:"ip";s:15:"166.111.163.204";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473756504;}s:64:"ed13c0821db58f96e5ee19161ead10f344a3cd20405730144fab87986a05c0e0";a:4:{s:10:"expiration";i:1473984401;s:2:"ip";s:13:"183.172.33.44";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473811601;}s:64:"ad84af33bca5d6ee26cd0de16036bb0bf3142683dc14a02c4a56424f5a0d27d6";a:4:{s:10:"expiration";i:1475026303;s:2:"ip";s:15:"166.111.163.204";s:2:"ua";s:129:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240";s:5:"login";i:1473816703;}}'),
 (70,1,'closedpostboxes_acf','a:0:{}'),
 (71,1,'metaboxhidden_acf','a:1:{i:0;s:7:"slugdiv";}'),
 (72,1,'meta-box-order_acf','a:3:{s:4:"side";s:9:"submitdiv";s:6:"normal";s:43:"acf_fields,acf_location,acf_options,slugdiv";s:8:"advanced";s:0:"";}'),
 (73,1,'screen_layout_acf','2'),
 (74,2,'性别','男'),
 (75,2,'_性别','field_57d76f2d8c355'),
 (76,2,'属性',''),
 (77,2,'_属性','field_57d770a7a8d5f'),
 (79,2,'sex','a:1:{i:0;s:3:"男";}'),
 (80,3,'sex',''),
 (81,2,'wp_metronet_post_id','87'),
 (82,2,'wp_metronet_image_id','64'),
 (83,2,'wp_metronet_avatar_override','on'),
 (84,1,'ecae_premium_ignore_count_notice','15'),
 (85,2,'account_status','approved'),
 (86,2,'role','member'),
 (87,3,'account_status','approved'),
 (88,3,'role','member'),
 (89,1,'account_status','approved'),
 (90,1,'role','admin'),
 (91,1,'wp_r_tru_u_x','a:2:{s:2:"id";i:0;s:7:"expires";i:1473809952;}'),
 (105,2,'_um_last_login','1473816703'),
 (93,2,'um_user_profile_url_slug_user_login','291477321'),
 (94,2,'profile_photo','profile_photo.jpg'),
 (95,2,'cover_photo','cover_photo.jpeg'),
 (96,2,'um_account_secure_fields','a:4:{s:7:"general";a:2:{s:10:"user_login";a:10:{s:5:"title";s:8:"Username";s:7:"metakey";s:10:"user_login";s:4:"type";s:4:"text";s:5:"label";s:8:"Username";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:0;s:8:"validate";s:15:"unique_username";s:9:"min_chars";i:3;s:9:"max_chars";i:24;}s:10:"user_email";a:7:{s:5:"title";s:14:"E-mail Address";s:7:"metakey";s:10:"user_email";s:4:"type";s:4:"text";s:5:"label";s:14:"E-mail Address";s:8:"required";i:0;s:6:"public";i:1;s:8:"validate";s:12:"unique_email";}}s:8:"password";a:1:{s:13:"user_password";a:11:{s:5:"title";s:8:"Password";s:7:"metakey";s:13:"user_password";s:4:"type";s:8:"password";s:5:"label";s:8:"Password";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:1;s:9:"min_chars";i:8;s:9:"max_chars";i:30;s:15:"force_good_pass";i:1;s:18:"force_confirm_pass";i:1;}}s:7:"privacy";a:2:{s:15:"profile_privacy";a:13:{s:5:"title";s:15:"Profile Privacy";s:7:"metakey";s:15:"profile_privacy";s:4:"type";s:6:"select";s:5:"label";s:15:"Profile Privacy";s:4:"help";s:32:"Who can see your public profile?";s:8:"required";i:0;s:6:"public";i:1;s:8:"editable";i:1;s:7:"default";s:8:"Everyone";s:7:"options";a:2:{i:0;s:8:"Everyone";i:1;s:7:"Only me";}s:10:"allowclear";i:0;s:12:"account_only";b:1;s:13:"required_perm";s:24:"can_make_private_profile";}s:15:"hide_in_members";a:12:{s:5:"title";s:30:"Hide my profile from directory";s:7:"metakey";s:15:"hide_in_members";s:4:"type";s:5:"radio";s:5:"label";s:30:"Hide my profile from directory";s:4:"help";s:61:"Here you can hide yourself from appearing in public directory";s:8:"required";i:0;s:6:"public";i:1;s:8:"editable";i:1;s:7:"default";s:2:"No";s:7:"options";a:2:{i:0;s:2:"No";i:1;s:3:"Yes";}s:12:"account_only";b:1;s:12:"required_opt";a:2:{i:0;s:12:"members_page";i:1;i:1;}}}s:6:"delete";a:1:{s:20:"single_user_password";a:8:{s:5:"title";s:8:"Password";s:7:"metakey";s:20:"single_user_password";s:4:"type";s:8:"password";s:5:"label";s:8:"Password";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:1;s:12:"account_only";b:1;}}}'),
 (97,3,'um_user_profile_url_slug_user_login','liujiahe'),
 (98,1,'closedpostboxes_um_form','a:0:{}'),
 (99,1,'metaboxhidden_um_form','a:6:{i:0;s:32:"um-admin-form-register_customize";i:1;s:26:"um-admin-form-register_css";i:2;s:29:"um-admin-form-login_customize";i:3;s:28:"um-admin-form-login_settings";i:4;s:23:"um-admin-form-login_css";i:5;s:7:"slugdiv";}'),
 (100,1,'um_user_profile_url_slug_user_login','owen'),
 (102,1,'nav_menu_recently_edited','20'),
 (104,1,'_um_last_login','1473816442'),
 (106,1,'closedpostboxes_post','a:0:{}'),
 (107,1,'metaboxhidden_post','a:4:{i:0;s:11:"postexcerpt";i:1;s:10:"postcustom";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
