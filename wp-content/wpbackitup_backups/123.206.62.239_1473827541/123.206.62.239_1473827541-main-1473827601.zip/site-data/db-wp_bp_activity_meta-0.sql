-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/14 on 04:33
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_bp_activity_meta
-- Snapshot Table  : 1473827541_bp_activity_meta
--
-- SQL    : SELECT * FROM wp_bp_activity_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473827541_bp_activity_meta`
--
DROP TABLE  IF EXISTS `1473827541_bp_activity_meta`;
CREATE TABLE `1473827541_bp_activity_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



--
-- Data for table `wp_bp_activity_meta`
-- Number of rows: 0
--
--
-- Data for table `wp_bp_activity_meta`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
