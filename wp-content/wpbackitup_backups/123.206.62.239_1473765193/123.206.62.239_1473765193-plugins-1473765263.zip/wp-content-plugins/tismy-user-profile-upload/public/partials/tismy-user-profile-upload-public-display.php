<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.squareonemd.co.uk
 * @since      1.0.0
 *
 * @package    Tismy_User_Profile_Upload
 * @subpackage Tismy_User_Profile_Upload/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
