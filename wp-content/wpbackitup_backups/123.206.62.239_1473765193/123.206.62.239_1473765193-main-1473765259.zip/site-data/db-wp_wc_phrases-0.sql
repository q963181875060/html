-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:14
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_wc_phrases
-- Snapshot Table  : 1473765193_wc_phrases
--
-- SQL    : SELECT * FROM wp_wc_phrases LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_wc_phrases`
--
DROP TABLE  IF EXISTS `1473765193_wc_phrases`;
CREATE TABLE `1473765193_wc_phrases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phrase_key` varchar(255) NOT NULL,
  `phrase_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `phrase_key` (`phrase_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



--
-- Data for table `wp_wc_phrases`
-- Number of rows: 0
--
--
-- Data for table `wp_wc_phrases`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
