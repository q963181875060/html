-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_bp_activity
-- Snapshot Table  : 1473765193_bp_activity
--
-- SQL    : SELECT * FROM wp_bp_activity LIMIT 0,10000
-- Offset : 0
-- Rows   : 4
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_bp_activity`
--
DROP TABLE  IF EXISTS `1473765193_bp_activity`;
CREATE TABLE `1473765193_bp_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `component` varchar(75) NOT NULL,
  `type` varchar(75) NOT NULL,
  `action` text NOT NULL,
  `content` longtext NOT NULL,
  `primary_link` text NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `date_recorded` datetime NOT NULL,
  `hide_sitewide` tinyint(1) DEFAULT '0',
  `mptt_left` int(11) NOT NULL DEFAULT '0',
  `mptt_right` int(11) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_recorded` (`date_recorded`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `component` (`component`),
  KEY `type` (`type`),
  KEY `mptt_left` (`mptt_left`),
  KEY `mptt_right` (`mptt_right`),
  KEY `hide_sitewide` (`hide_sitewide`),
  KEY `is_spam` (`is_spam`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;



--
-- Data for table `wp_bp_activity`
-- Number of rows: 4
--
INSERT INTO `1473765193_bp_activity` VALUES 
(1,2,'profile','new_avatar','<a href="http://123.206.62.239/members/291477321/" title="291477321">291477321</a> changed their profile picture','','http://123.206.62.239/members/291477321/',0,0,'2016-09-10 08:52:45',0,0,0,0),
 (2,2,'members','last_activity','','','',0,NULL,'2016-09-10 09:10:10',0,0,0,0),
 (3,3,'members','last_activity','','','',0,NULL,'2016-09-10 09:42:28',0,0,0,0),
 (4,1,'members','last_activity','','','',0,NULL,'2016-09-10 09:44:21',0,0,0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
