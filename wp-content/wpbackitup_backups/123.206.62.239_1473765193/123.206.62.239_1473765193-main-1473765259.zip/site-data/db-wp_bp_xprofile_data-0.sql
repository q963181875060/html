-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_bp_xprofile_data
-- Snapshot Table  : 1473765193_bp_xprofile_data
--
-- SQL    : SELECT * FROM wp_bp_xprofile_data LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_bp_xprofile_data`
--
DROP TABLE  IF EXISTS `1473765193_bp_xprofile_data`;
CREATE TABLE `1473765193_bp_xprofile_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `value` longtext NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;



--
-- Data for table `wp_bp_xprofile_data`
-- Number of rows: 3
--
INSERT INTO `1473765193_bp_xprofile_data` VALUES 
(1,1,1,'owen','2016-09-10 08:45:48'),
 (2,1,2,'291477321','2016-09-10 08:52:50'),
 (3,1,3,'liujiahe','2016-09-10 09:37:05');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
