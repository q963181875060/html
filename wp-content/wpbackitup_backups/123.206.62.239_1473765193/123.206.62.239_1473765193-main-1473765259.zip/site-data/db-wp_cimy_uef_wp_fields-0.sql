-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:14
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_cimy_uef_wp_fields
-- Snapshot Table  : 1473765193_cimy_uef_1473765193_fields
--
-- SQL    : SELECT * FROM wp_cimy_uef_wp_fields LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_cimy_uef_1473765193_fields`
--
DROP TABLE  IF EXISTS `1473765193_cimy_uef_1473765193_fields`;
CREATE TABLE `1473765193_cimy_uef_1473765193_fields` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `F_ORDER` bigint(20) NOT NULL,
  `NAME` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `LABEL` text COLLATE utf8mb4_unicode_520_ci,
  `DESCRIPTION` text COLLATE utf8mb4_unicode_520_ci,
  `TYPE` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `RULES` text COLLATE utf8mb4_unicode_520_ci,
  `VALUE` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`ID`),
  KEY `F_ORDER` (`F_ORDER`),
  KEY `NAME` (`NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_cimy_uef_wp_fields`
-- Number of rows: 0
--
--
-- Data for table `wp_cimy_uef_wp_fields`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
