-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_cimy_uef_fields
-- Snapshot Table  : 1473765193_cimy_uef_fields
--
-- SQL    : SELECT * FROM wp_cimy_uef_fields LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_cimy_uef_fields`
--
DROP TABLE  IF EXISTS `1473765193_cimy_uef_fields`;
CREATE TABLE `1473765193_cimy_uef_fields` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `F_ORDER` bigint(20) NOT NULL,
  `FIELDSET` bigint(20) NOT NULL DEFAULT '0',
  `NAME` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `LABEL` text COLLATE utf8mb4_unicode_520_ci,
  `DESCRIPTION` text COLLATE utf8mb4_unicode_520_ci,
  `TYPE` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `RULES` text COLLATE utf8mb4_unicode_520_ci,
  `VALUE` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`ID`),
  KEY `F_ORDER` (`F_ORDER`),
  KEY `NAME` (`NAME`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_cimy_uef_fields`
-- Number of rows: 1
--
INSERT INTO `1473765193_cimy_uef_fields` VALUES 
(2,1,0,'性别','性别','选中表示男，否则女','radio','a:11:{s:5:"email";b:0;s:11:"email_admin";b:0;s:12:"can_be_empty";b:1;s:4:"edit";s:7:"ok_edit";s:16:"advanced_options";s:0:"";s:11:"show_in_reg";b:1;s:15:"show_in_profile";b:1;s:11:"show_in_aeu";b:1;s:14:"show_in_search";b:0;s:12:"show_in_blog";b:0;s:10:"show_level";s:2:"-1";}','');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
