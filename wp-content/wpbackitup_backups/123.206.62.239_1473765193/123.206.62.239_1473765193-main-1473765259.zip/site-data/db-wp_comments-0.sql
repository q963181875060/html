-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_comments
-- Snapshot Table  : 1473765193_comments
--
-- SQL    : SELECT * FROM wp_comments LIMIT 0,10000
-- Offset : 0
-- Rows   : 14
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_comments`
--
DROP TABLE  IF EXISTS `1473765193_comments`;
CREATE TABLE `1473765193_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_comments`
-- Number of rows: 14
--
INSERT INTO `1473765193_comments` VALUES 
(1,1,'Mr WordPress','','https://wordpress.org/','','2016-09-07 06:14:20','2016-09-07 06:14:20','Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.',0,'1','','',0,0),
 (2,1,'owen','279340843@qq.com','','166.111.163.204','2016-09-10 03:39:29','2016-09-10 03:39:29','fsdfs',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,1),
 (3,1,'liujiahe','liujiahe14@mails.tsinghua.edu.cn','','159.203.228.184','2016-09-10 09:23:26','2016-09-10 09:23:26','test',0,'1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','',0,3),
 (4,41,'liujiahe','liujiahe14@mails.tsinghua.edu.cn','','159.203.228.184','2016-09-10 09:31:14','2016-09-10 09:31:14','test1',0,'1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','',0,3),
 (5,1,'liujiahe','liujiahe14@mails.tsinghua.edu.cn','','159.203.228.184','2016-09-10 09:40:39','2016-09-10 09:40:39','test1',0,'1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','',0,3),
 (6,44,'liujiahe','liujiahe14@mails.tsinghua.edu.cn','','159.203.228.184','2016-09-10 09:44:14','2016-09-10 09:44:14','hao',0,'1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','',0,3),
 (7,44,'owen','279340843@qq.com','','166.111.163.204','2016-09-10 09:45:42','2016-09-10 09:45:42','喝哦',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,1),
 (8,44,'owen','279340843@qq.com','','166.111.163.204','2016-09-10 09:46:34','2016-09-10 09:46:34','顺丰速递',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,1),
 (9,44,'owen','279340843@qq.com','','166.111.163.204','2016-09-10 09:48:00','2016-09-10 09:48:00','水电费水电费啊',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,1),
 (10,44,'291477321','291477321@qq.com','http://www.360doc.com/content/11/0715/11/474846_133688425.shtml','166.111.163.204','2016-09-10 10:48:39','2016-09-10 10:48:39','good',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,2),
 (11,44,'owen','279340843@qq.com','','166.111.163.204','2016-09-10 11:34:52','2016-09-10 11:34:52','非常好！',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,1),
 (12,34,'owen','279340843@qq.com','','159.203.228.184','2016-09-12 01:58:48','2016-09-12 01:58:48','fefef',0,'1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','',0,1),
 (13,44,'291477321','291477321@qq.com','http://www.360doc.com/content/11/0715/11/474846_133688425.shtml','101.5.104.125','2016-09-12 02:04:17','2016-09-12 02:04:17','wokeyi',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,2),
 (14,76,'291477321','291477321@qq.com','http://www.360doc.com/content/11/0715/11/474846_133688425.shtml','166.111.163.204','2016-09-13 02:38:53','2016-09-13 02:38:53','sdfs',0,'1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240','',0,2);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
