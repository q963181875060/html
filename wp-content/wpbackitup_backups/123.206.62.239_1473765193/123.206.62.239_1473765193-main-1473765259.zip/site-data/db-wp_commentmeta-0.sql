-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_commentmeta
-- Snapshot Table  : 1473765193_commentmeta
--
-- SQL    : SELECT * FROM wp_commentmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 12
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_commentmeta`
--
DROP TABLE  IF EXISTS `1473765193_commentmeta`;
CREATE TABLE `1473765193_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_commentmeta`
-- Number of rows: 12
--
INSERT INTO `1473765193_commentmeta` VALUES 
(1,6,'wpdiscuz_votes','0'),
 (2,7,'wpdiscuz_votes','0'),
 (3,8,'wpdiscuz_votes','0'),
 (4,9,'wpdiscuz_votes','0'),
 (5,10,'wpdiscuz_votes','0'),
 (6,6,'wpdiscuz_child_ids',''),
 (7,7,'wpdiscuz_child_ids',''),
 (8,8,'wpdiscuz_child_ids',''),
 (9,9,'wpdiscuz_child_ids',''),
 (10,10,'wpdiscuz_child_ids',''),
 (11,11,'wpdiscuz_votes','0'),
 (12,11,'wpdiscuz_child_ids','');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
