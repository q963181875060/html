-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2016/09/13 on 11:13
--
-- Database : XD8NoLuX
--
-- Backup   Table  : wp_postmeta
-- Snapshot Table  : 1473765193_postmeta
--
-- SQL    : SELECT * FROM wp_postmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 54
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `1473765193_postmeta`
--
DROP TABLE  IF EXISTS `1473765193_postmeta`;
CREATE TABLE `1473765193_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wp_postmeta`
-- Number of rows: 54
--
INSERT INTO `1473765193_postmeta` VALUES 
(1,2,'_wp_page_template','default'),
 (2,5,'_edit_lock','1473328493:1'),
 (3,5,'_edit_last','1'),
 (4,6,'_wp_attached_file','2016/09/616380150380117437.jpg'),
 (5,6,'_wp_attachment_metadata','a:5:{s:5:"width";i:960;s:6:"height";i:1280;s:4:"file";s:30:"2016/09/616380150380117437.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"616380150380117437-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"616380150380117437-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"616380150380117437-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"616380150380117437-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:30:"616380150380117437-825x510.jpg";s:5:"width";i:825;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
 (6,32,'_edit_lock','1473498590:2'),
 (7,32,'_edit_last','2'),
 (8,34,'_edit_lock','1473499125:3'),
 (9,34,'_edit_last','1'),
 (11,37,'_edit_lock','1473498518:2'),
 (12,41,'_edit_lock','1473499334:3'),
 (13,41,'_edit_last','3'),
 (15,43,'_edit_lock','1473500381:3'),
 (16,44,'_edit_lock','1473507227:1'),
 (17,44,'_edit_last','1'),
 (19,46,'_edit_lock','1473507894:1'),
 (20,47,'_edit_lock','1473560342:3'),
 (21,50,'_edit_lock','1473565648:1'),
 (26,55,'_edit_last','2'),
 (28,57,'_edit_lock','1473730616:2'),
 (29,57,'_edit_last','2'),
 (30,61,'_edit_lock','1473649331:2'),
 (31,61,'_edit_last','2'),
 (33,63,'_edit_lock','1473649946:2'),
 (34,64,'_wp_attached_file','2016/09/白底头像.jpg'),
 (35,64,'_wp_attachment_metadata','a:5:{s:5:"width";i:924;s:6:"height";i:1240;s:4:"file";s:24:"2016/09/白底头像.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"白底头像-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"白底头像-224x300.jpg";s:5:"width";i:224;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"白底头像-768x1031.jpg";s:5:"width";i:768;s:6:"height";i:1031;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"白底头像-763x1024.jpg";s:5:"width";i:763;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"白底头像-825x510.jpg";s:5:"width";i:825;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"11";s:6:"credit";s:0:"";s:6:"camera";s:9:"NIKON D70";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1259491238";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"70";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
 (25,55,'_edit_lock','1473646375:2'),
 (36,65,'_edit_lock','1473659681:2'),
 (37,65,'_edit_last','2'),
 (40,69,'_edit_lock','1473659179:2'),
 (41,69,'_edit_last','2'),
 (43,64,'_wp_attachment_is_custom_background','spacious'),
 (44,72,'_edit_lock','1473653216:1'),
 (45,73,'_edit_lock','1473656913:2'),
 (46,74,'_edit_lock','1473656938:2'),
 (47,75,'_edit_lock','1473659097:2'),
 (48,76,'_edit_lock','1473734324:2'),
 (49,76,'_edit_last','2'),
 (50,76,'_thumbnail_id','64'),
 (52,78,'_edit_lock','1473659265:2'),
 (53,79,'_edit_lock','1473659372:2'),
 (54,81,'_edit_lock','1473659475:2'),
 (55,82,'_edit_lock','1473662251:3'),
 (56,83,'_edit_lock','1473662284:3'),
 (57,85,'_edit_lock','1473736100:1'),
 (58,86,'_edit_lock','1473754096:1'),
 (59,86,'_edit_last','1'),
 (60,86,'field_57d76f2d8c355','a:13:{s:3:"key";s:19:"field_57d76f2d8c355";s:5:"label";s:6:"性别";s:4:"name";s:6:"性别";s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:7:"choices";a:2:{s:3:"男";s:3:"男";s:3:"女";s:3:"女";}s:12:"other_choice";s:1:"0";s:17:"save_other_choice";s:1:"0";s:13:"default_value";s:3:"男";s:6:"layout";s:10:"horizontal";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
 (63,86,'position','normal'),
 (64,86,'layout','no_box'),
 (65,86,'hide_on_screen',''),
 (66,86,'field_57d770a7a8d5f','a:11:{s:3:"key";s:19:"field_57d770a7a8d5f";s:5:"label";s:6:"属性";s:4:"name";s:6:"属性";s:4:"type";s:8:"checkbox";s:12:"instructions";s:36:"选择您自己的属性，可多选";s:8:"required";s:1:"1";s:7:"choices";a:2:{s:3:"主";s:3:"主";s:3:"奴";s:3:"奴";}s:13:"default_value";s:0:"";s:6:"layout";s:10:"horizontal";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_57d76f2d8c355";s:8:"operator";s:2:"==";s:5:"value";s:3:"男";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
 (92,86,'rule','a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"13";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
 (93,87,'_thumbnail_id','64');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
