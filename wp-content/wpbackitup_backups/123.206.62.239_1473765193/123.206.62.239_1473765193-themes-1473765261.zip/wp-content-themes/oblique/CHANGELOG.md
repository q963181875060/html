
### 1.13 - 26/08/2016
**Changes:** 
- Fixed Issue with Jetpack Infinite scroll

### 1.12 - 18/08/2016
**Changes:** 
- Fixed masonry issue with WordPress 4.6

### 1.11 - 14/06/2016
**Changes:** 
- Update documentation links
- Fixed layout issues on mobile in single posts


### 1.09 - 19/01/2016

 Changes: 


 * Merge pull request #10 from abaicus/development

!!! Changed author name and uri.


### 1.08 - 14/12/2015

 Changes: 


 * Fixed sidebar dropdown text color
 * Optimized screenshot size. Fixes ineagu/https://github.com/Codeinwp/oblique.git#4
 * Merge pull request #2 from abaicus/development

Fixed sidebar dropdowns text color.
 * Merge branch 'development' of https://github.com/Codeinwp/oblique into development
 * Added TGM plugin activator
 * Merge pull request #8 from abaicus/development

Added TGM plugin activator
 * Merge https://github.com/Codeinwp/oblique into development
 * Merge branch 'development' of https://github.com/abaicus/oblique into development
 * Merge branch 'development' of https://github.com/Codeinwp/oblique into development
 * Merge pull request #9 from abaicus/development

!!!Removed Theme extensions section from customizer. Added buttons to top of customizer sidebar.
